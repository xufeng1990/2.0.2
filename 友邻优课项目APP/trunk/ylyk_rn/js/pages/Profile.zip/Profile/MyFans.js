//  MyFans
//  功能: TODO 该类的作用
//  Created by 刘云强 on  2016-10-20
//  Copyright © 2017年  琢磨科技.

'use strict';
import React, { Component,} from 'react';
import {
  Text,
  View,
  Image,
  TextInput,
  ScrollView,
  ListView,
  StyleSheet,
  TouchableOpacity,
  TouchableHighlight,
  TouchableWithoutFeedback,
  Alert,
  NativeModules,
  DeviceEventEmitter
} from 'react-native';
import NavigationBar from '../../component/Navigator/NavigationBar.js';
import g_AppValue from '../../configs/AppGlobal.js';
import ProfileRowCell from '../../component/AlbumCell/ProfileRowCell.js';
import StudentsInformation from './StudentsInformation.js';
import * as ImgUrl from '../../configs/BaseImgUrl.js';
import *as RnNativeModules  from '../../configs/RnNativeModules.js';
const getFanslist = NativeModules.NativeNetwork;
const Followee = NativeModules.NativeNetwork;
// 类
export default class MyFans extends Component {

  // 构造函数
  constructor(props) {
    super(props);
    this.state = {
      //关注状态
      followee:this.props.fansData.map((item) =>{return item.is_followee}),
      //再次请求数据
      fansDatasssss:this.props.fansData,
       fansData:[],
    };
  }

  componentDidMount(){
    //二界面关注状态传回
    this.changeRowId = DeviceEventEmitter.addListener('changeRowId',(rowID)=>{
      //console.log('更新前的' + this.state.followee)
      var arr = this.state.followee;
        arr[rowID] = !arr[rowID];
     this.setState({
       followee:arr,
     })
    })

  }
componentWillUnmount(){
  this.changeRowId && this.changeRowId.remove();
}


_goToInformationPage(fansId,is_followee,rowID){
  var is_followee = this.state.followee[rowID];
  this.props.navigator.push({
    component:StudentsInformation,
    params:{
      fansId:fansId,
      is_followee:is_followee,
      rowID:rowID
    }
  })
}
_goBack(){
  var user_id = this.props.user_id;
  DeviceEventEmitter.emit('refreshData',user_id);
  RnNativeModules.hideTabBar('show');

  this.props.navigator.pop();

}
//关注按钮实现
_focusAction(rowData,sectionID,rowID){

    if (rowData.is_followee == false) {
      Followee.createFollowee({'user_id':rowData.user.id })
      .then((data) =>{
        var arr = this.state.followee;
          arr[rowID] = !arr[rowID]
        this.setState({
          followee:arr,
        })
      }).catch((err)=>{
        console.log("关注失败" + err)
      })
    }
    else {
      Followee.deleteFollowee({'user_id':rowData.user.id })
      .then((data) =>{
        var arr =this.state.followee
        arr[rowID] = !  arr[rowID]
        this.setState({
          followee:arr
        })
      }).catch((err)=>{
        console.log("取消关注失败" + err)
      })
    }
}

_renderRow(rowData,sectionID,rowID){
  let fansId = rowData.user.id;
  let is_followee = rowData.is_followee;
  
  return(
    <TouchableOpacity onPress={()=>{this._goToInformationPage(fansId,is_followee,rowID)}}>
      <ProfileRowCell
        name = {rowData.user.nickname}
        headerImage = {{uri:ImgUrl.baseImgUrl + 'user/' + rowData.user.id +'/avatar'}}
        contentText = {rowData.user.intro}
        focusImagePath = { this.state.followee[rowID] ? require('../Course/images/Focus2.png') : require('../Course/images/Focus1.png')}
          foucsActionFnc = {() => this._focusAction(rowData,sectionID,rowID)}
        />
        </TouchableOpacity>
  );
}
  // render
  render(){
//执行循序
  if (!this.state.fansDatasssss) {
    return(<View></View>)
  }

var data = this.state.fansDatasssss;
var ds = new ListView.DataSource({rowHasChanged: (r1,r2) => r1 !== r2});
var dataSource = ds.cloneWithRows(data);
    return (
      <View style={styles.container}>
      <View style={styles.headerView}>
        <Text style={styles.titleText} >粉丝</Text>
        <TouchableOpacity  style={styles.touchBackImage}  onPress={this._goBack.bind(this)}>
        <Image style={styles.backImage} source= {require('../Course/images/back1.png')} />
            </TouchableOpacity>
      </View>
      <ListView
        ref = 'scrollView'
        enableEmptySections={true}
        dataSource={dataSource}
        renderRow={this._renderRow.bind(this)}
        />


        </View>
    );
  }

}

// {data.map((item, i) => this._renderItem(item,i))}
var styles = StyleSheet.create({
  container:{
    flex:1,
    backgroundColor:'#f2f5f6',
  },
  headerView:{
    width:g_AppValue.screenWidth,
    height:65 * g_AppValue.precent,
    alignItems:'center',
    backgroundColor:'#ffffff',
  },
  titleText:{
    marginTop:34 * g_AppValue.precent,
    fontSize:18 * g_AppValue.precent,
    color:'#5a5a5a',
  },
  touchBackImage:{
    position:'absolute',
    top:33 * g_AppValue.precent,
    left:12 * g_AppValue.precent,
  },
  backImage:{
    width:10 * g_AppValue.precent,
    height:18 * g_AppValue.precent,
  },
  rowView:{
    width:g_AppValue.screenWidth,
    height:82 * g_AppValue.precent,
    backgroundColor:'#ffffff',
    marginTop:10 * g_AppValue.precent,
    flexDirection:'row',
  },
  headerImage:{
    width:58 * g_AppValue.precent,
    height:58 * g_AppValue.precent,
    marginTop:15 * g_AppValue.precent,
    marginLeft:12 * g_AppValue.precent,
  },
  cintentView:{
    width:200 * g_AppValue.precent,
    height:35 * g_AppValue.precent,
    // backgroundColor:'red',
    marginLeft:12 * g_AppValue.precent,
    marginTop:25 * g_AppValue.precent,
  },
  nameText:{
    fontSize:14 * g_AppValue.precent,
    color:'#5a5a5a',
  },
  introduceText:{
    fontSize:11 * g_AppValue.precent,
    color:'#9a9b9c',
    marginTop:8 * g_AppValue.precent,
  },
  touchFocusImage:{
  //  backgroundColor:'black',
    position:'absolute',
    top:31 * g_AppValue.precent,
    right:12 * g_AppValue.precent,
    bottom:30 * g_AppValue.precent,
  },
  focusImage:{
    width:54 * g_AppValue.precent,
    height:21 * g_AppValue.precent,

  }

})
