//  "My download"
//  功能: TODO 该类的作用
//  Created by 刘云强 on  2016-10-20
//  Copyright © 2017年  琢磨科技.

'use strict';
import React, { Component,} from 'react';
import {
  Text,
  View,
  Image,
  TextInput,
  ScrollView,
  ListView,
  StyleSheet,
  TouchableOpacity,
  TouchableHighlight,
  TouchableWithoutFeedback,
  Alert,
} from 'react-native';
import g_AppValue from '../../configs/AppGlobal.js';
// 类
export default class MyDownload extends Component {
  // 构造函数
  constructor(props) {
    super(props);
    this.state = {
      // your code
    };
  }

  // 加载完成
  componentDidMount(){
    //
  }

  // view卸载
  componentWillUnmount(){
    //
  }
_rowRow(){
  return(
    <TouchableOpacity>
    <View style={styles.rowView} >
      <View style={styles.contentView} >
        <Image style={styles.contentImage} source={require('../Course/images/f.png')}/>
        <Text style={styles.titleText}>wwww</Text>
      </View>
    </View>
    </TouchableOpacity>
  );
}
  // render
  render(){
    var data = [1,2,3,4,5,6];
    var ds = new ListView.DataSource({rowHasChanged: (r1,r2) => r1 !== r2});
    var dataSource = ds.cloneWithRows(data);
    return (
      <View style={styles.container}>
        <View style = {styles.newsTitleView}>
        <Text style={styles.newsTitle}>我的下载</Text>
        <TouchableOpacity style = {styles.touchRightImage} >
        <Image  style = {styles.rightImage} source={require('../Course/images/more.png')}/>
        </TouchableOpacity>
          </View>

          <ListView
            ref = 'scrollView'
            style={styles.listView}
            horizontal = {true}
            enableEmptySections={true}
            dataSource={dataSource}
            renderRow={this._rowRow.bind(this)}
            />


      </View>
    );
  }

  // 自定义方法区域
  // your method

}

var styles = StyleSheet.create({
  container:{
    flex:1,
    width:g_AppValue.screenWidth,
    height:161 * g_AppValue.precent,
   backgroundColor:'#ffffff',
    marginTop:10 * g_AppValue.precent,
  },
  newsTitleView:{
    width:g_AppValue.screenWidth,
    height:18 * g_AppValue.precent,
    marginTop:12 * g_AppValue.precent,
  //  backgroundColor:'green',
    flexDirection:'row',
  },
  newsTitle:{
    textAlign:'center',
    fontSize:16 * g_AppValue.precent,
    marginLeft:12  *g_AppValue.precent,

  },
  touchRightImage:{
    //marginTop:2.5 * g_AppValue.precent,
    flexDirection:'row-reverse',
    position:'absolute',
    right:10 * g_AppValue.precent,
    width:7 * g_AppValue.precent,
    height:18 * g_AppValue.precent,
    //backgroundColor:'yellow',
  },
  rightImage:{

    width:7 * g_AppValue.precent,
    height:18 * g_AppValue.precent,

  },
  listView:{
    flex:1,
  },
  rowView:{
    width:90 * g_AppValue.precent,
    height:113 * g_AppValue.precent,
    backgroundColor:'#ffffff',
    marginTop:10 * g_AppValue.precent,
    marginLeft:10 * g_AppValue.precent,

  },
  contentImage:{
    width:90  *g_AppValue.precent,
    height:90  *g_AppValue.precent,
    backgroundColor:'black',

  },
  titleText:{
    marginTop:10  *g_AppValue.precent,
    fontSize:11  *g_AppValue.precent,
    color:'#9a9b9c',
  },

});
