//  ProfileView
//  功能: TODO 该类的作用
//  Created by 刘云强 on  2016-10-20
//  Copyright © 2017年  琢磨科技.

'use strict';
import React, { Component,} from 'react';
import {
  Text,
  View,
  Image,
  TextInput,
  ScrollView,
  ListView,
  StyleSheet,
  TouchableOpacity,
  TouchableHighlight,
  TouchableWithoutFeedback,
  Alert,
  NativeModules,
} from 'react-native';
import g_AppValue from '../../configs/AppGlobal.js';
import MyThumb from './MyThumb/MyThumb.js';
import Loading from '../../component/Loading/Loading.js';
import *as RnNativeModules from '../../configs/RnNativeModules.js';
const getFanslist = NativeModules.NativeNetwork;
// 类
export default class ProfileView extends Component {
  // 构造函数
  constructor(props) {
    super(props);
    this.state = {
    fansData:[],
    };
  }

  // 加载完成
  componentDidMount(){

  }

  // view卸载
  componentWillUnmount(){
    //
  }
  _myThumbView(){
    RnNativeModules.hideTabBar('hide')
    const navigator = this.props.navigator;
    this.props.navigator.push({
      component:MyThumb,
      params:{
        user_id:this.props.user_id,
        navigator:navigator,
      }
    })
  }


  // render
  render(){

    return (

      <View style={styles.container} >
        <TouchableOpacity onPress={this._myThumbView.bind(this)}>
        <View style={styles.praiseView}>
          <View style = {styles.newsTitleView}>
          <Text style={styles.newsTitle}>我赞过的</Text>
          <Image  style = {styles.rightImage} source={require('../Course/images/more.png')}/>
            </View>
            </View>
      </TouchableOpacity>
        <View style={styles.aLLRowView}>
          <TouchableOpacity >
          <View style={styles.rowView} >
            <View style = {styles.newsTitleView}>
            <Text style={styles.newsTitle}>同学权益</Text>
            <Image  style = {styles.rightImage} source={require('../Course/images/more.png')}/>
              </View>
              <View style={styles.lineView} />
          </View>
            </TouchableOpacity>
            <TouchableOpacity >
            <View style={styles.rowView} >
              <View style = {styles.newsTitleView}>
              <Text style={styles.newsTitle}>任务中心</Text>
              <Image  style = {styles.rightImage} source={require('../Course/images/more.png')}/>
                </View>
                <View style={styles.lineView} />
            </View>
              </TouchableOpacity>
              <TouchableOpacity>
              <View style={styles.rowView} >
                <View style={styles.coinView}>
                  <Text style={styles.coinText} >100000优币</Text>
                </View>
                <View style = {styles.newsTitleView}>
                <Text style={styles.newsTitle}>优币商城</Text>
                <Image  style = {styles.rightImage} source={require('../Course/images/more.png')}/>
                  </View>
                  <View style={styles.lineView} />
              </View>
                </TouchableOpacity>
                <TouchableOpacity>
                <View style={styles.rowView} >
                  <View style={styles.coinView}>
                    <Text style={styles.coinText} >2277366673</Text>
                  </View>
                  <View style = {styles.newsTitleView}>
                  <Text style={styles.newsTitle}>微信号</Text>
                  <Image  style = {{marginLeft:295*g_AppValue.precent,
                    width:7 * g_AppValue.precent,
                    height:18 * g_AppValue.precent,}} source={require('../Course/images/more.png')}/>
                    </View>
                </View>
                  </TouchableOpacity>
        </View>

        <TouchableOpacity>
        <View style={styles.praiseView}>
          <View style = {styles.newsTitleView}>
          <Text style={styles.newsTitle}>学习管家</Text>
          <Image  style = {styles.rightImage} source={require('../Course/images/more.png')}/>
            </View>
            </View>
      </TouchableOpacity>
      </View>


    );
  }

  // 自定义方法区域
  // your method

}

var styles = StyleSheet.create({
  container:{
  flex:1,
  },
  praiseView:{
    width:g_AppValue.screenWidth,
    height:56  *g_AppValue.precent,
    backgroundColor:'#ffffff',
    marginTop:10  *g_AppValue.precent,
    alignItems:'center',
    justifyContent:'center',
  },
  newsTitleView:{
    width:g_AppValue.screenWidth,
    height:18 * g_AppValue.precent,
    //backgroundColor:'red',
    flexDirection:'row',
  },
  newsTitle:{
    textAlign:'center',
    fontSize:16 * g_AppValue.precent,
    marginLeft:12  *g_AppValue.precent,
  },

  rightImage:{
    marginLeft:278 * g_AppValue.precent,
    width:7 * g_AppValue.precent,
    height:18 * g_AppValue.precent,
  },
  aLLRowView:{
    marginTop:10  *g_AppValue.precent,
    width:g_AppValue.screenWidth,

    //backgroundColor:'red',
  },
  rowView:{
    width:g_AppValue.screenWidth,
    height:56  *g_AppValue.precent,
    backgroundColor:'#ffffff',

    justifyContent:'center',
  },
  lineView:{
    position:'absolute',
    backgroundColor:'#c8c8c8',
    opacity:0.5,
    width:351  *g_AppValue.precent,
    height:1  *g_AppValue.precent,
    top:55  *g_AppValue.precent,
    left:12  *g_AppValue.precent,
  },
  coinView:{
    flex:1,
    position:'absolute',
    top:21 * g_AppValue.precent,
    right:31 * g_AppValue.precent,
    justifyContent:'flex-end'
  },
  coinText:{
    fontSize:14 * g_AppValue.precent,
    color:'#9a9b9c',
  }
});
