//  AlbumNote
//  功能: TODO 该类的作用
//  Created by 刘云强 on  2016-10-20
//  Copyright © 2017年  琢磨科技.

'use strict';
import React, { Component,} from 'react';
import {
  Text,
  View,
  Image,
  TextInput,
  ScrollView,
  ListView,
  StyleSheet,
  TouchableOpacity,
  TouchableHighlight,
  TouchableWithoutFeedback,
  Alert,
  NativeModules,
} from 'react-native';
import * as ImgUrl from '../../configs/BaseImgUrl.js';
import g_AppValue from '../../configs/AppGlobal.js';
import NoteCell from '../../component/AlbumCell/noteCell.js';
import *as RnNativeModules from '../../configs/RnNativeModules.js';
import Util from '../../common/util.js';

const fansNoteList = NativeModules.NativeNetwork;
export default class FocusInformationNote extends Component {
  // 构造函数
  constructor(props) {
    super(props);
    this.focus = true
    this.state = {
      focusChange:true,
      noteList:'',
    };
  }

  // 加载完成
  componentDidMount(){
    fansNoteList.getNoteList({'page':1,'user_id':this.props.user_id})
  .then((data)=> {
    this.setState({noteList:JSON.parse(data),})
  }).catch((err)=> { console.warn('数据err', err);});
  }

  // view卸载
  componentWillUnmount(){

  }
  _focusC(){
    if (this.focus) {
      this.setState({
        focusChange:false
      })
      this.focus = false
    }else {
      this.setState({
        focusChange:true
      })
      this.focus = true
    }
  }
  _noteGotoPlay(payId){
    RnNativeModules.goToPlayerView(payId + '');
  }

  _rowRow(rowData){
      var payId = rowData.course.id;
    return(
      <NoteCell
        headPortraitImage = {{uri:ImgUrl.baseImgUrl + 'user/' + this.props.user_id +'/avatar'}}
        name = {this.props.user_name}
        time = {Util.dateFormat(rowData.in_time,'yyyy-MM-dd')}
        content = {rowData.content}
        playImage = {{uri:ImgUrl.baseImgUrl + 'course/' + rowData.course.id +'/avatar'}}
        playTitle = {rowData.course.name}
        playName = 'hehehehh'
        palyAction = {()=>this._noteGotoPlay(payId)}
        thumbNumber ={rowData.like_count}
        foucsActionFnc = {()=>{this._focusChange()}}
        focusChangeImage = {this.state.focusChange ? require('../Course/images/Focus1.png') : require('../Course/images/Focus2.png')}
        imagesData = {rowData.images}
        noteTouchInage = {() =>{this._noteTouchImages()}}

        />
    );
  }
  // render
  render(){
    var data = this.state.noteList;
    var ds = new ListView.DataSource({rowHasChanged: (r1,r2) => r1 !== r2});
    var dataSource = ds.cloneWithRows(data);
    return (
      <View style ={{flex:1}}>

          <ListView
            ref = 'scrollView'
            style={styles.listView}
            enableEmptySections={true}
            dataSource={dataSource}
            scrollEnabled = {false}
            renderRow={this._rowRow.bind(this)}

            />
      </View>

    );
  }

  // 自定义方法区域
  // your method

}
var styles = StyleSheet.create({
  listView:{
    flex:1,
    backgroundColor:'#f2f5f6',
  },
  container:{
    flex:1,
     width:g_AppValue.screenWidth,
    backgroundColor:'#ffffff',
    marginTop:10 * g_AppValue.precent,
    flexDirection:'row',

  },
  HeadPortraitImage:{
    width:39 * g_AppValue.precent,
    height:39 * g_AppValue.precent,
    marginTop:12 * g_AppValue.precent,
    marginLeft:12 * g_AppValue.precent,

  },
  FocusImage:{
    width:54 * g_AppValue.precent,
    height:21 * g_AppValue.precent,
    position:'absolute',
    top:0 * g_AppValue.precent,
    right:12 * g_AppValue.precent,

  },
  rightBigView:{
    flex:1,
    width:295 * g_AppValue.precent,
    //backgroundColor:'green',
    marginTop:17 * g_AppValue.precent,
    marginLeft:10 * g_AppValue.precent,
  },
  nameText:{
    width:200 * g_AppValue.precent,
    fontSize:14 * g_AppValue.precent,
    color:'#5a5a5a',
    textAlign:'left',
  },
  timeText:{
      width:200 * g_AppValue.precent,
    marginTop:5 * g_AppValue.precent,
    fontSize:11 * g_AppValue.precent,
    color:'#9a9b9c',
    textAlign:'left',
  },
  contentText:{
    width:295 * g_AppValue.precent,
    marginTop:8 * g_AppValue.precent,
    fontSize:13 * g_AppValue.precent,
    color:'#5a5a5a',
    textAlign:'left',
  },
  ImageView:{
    flex:1,
    width:294 * g_AppValue.precent,
    marginLeft:-20 * g_AppValue.precent,
    flexWrap:'wrap',
    flexDirection:'row',
  },
  imageItem:{
    width:88* g_AppValue.precent,
    height:88 * g_AppValue.precent,
    marginTop:10 * g_AppValue.precent,
    marginLeft:10 * g_AppValue.precent,
  },
  payView:{
    marginTop:20 * g_AppValue.precent,
    width:284 * g_AppValue.precent,
    height:48 * g_AppValue.precent,
    flexDirection:'row',

  },
  payImageOne:{
    width:64 * g_AppValue.precent,
    height:48 * g_AppValue.precent,

  },
  payImageTwo:{
    position:'absolute',
    top:0 * g_AppValue.precent,
    width:64 * g_AppValue.precent,
    height:48 * g_AppValue.precent,
  },
  payRightView:{
    marginLeft:10 * g_AppValue.precent,
    width:210 * g_AppValue.precent,
    height:48 * g_AppValue.precent,
  },
  payRightTitleText:{
    marginTop:8 * g_AppValue.precent,
    fontSize:13 * g_AppValue.precent,
    color:'#5a5a5a',
    textAlign:'left',
  },
  payRightNameText:{
    marginTop:4 * g_AppValue.precent,
    fontSize:12 * g_AppValue.precent,
    color:'#5a5a5a',
    textAlign:'left',
  },
  ThumbView:{
    flex:1,
    height:16 * g_AppValue.precent,
    marginTop:15 * g_AppValue.precent,
    marginBottom:14 * g_AppValue.precent,
    marginRight:12* g_AppValue.precent,
    justifyContent:'flex-end',
    flexDirection:'row',

  },
  thumbImage:{
    width:16 * g_AppValue.precent,
    height:16 * g_AppValue.precent,
    marginRight:6 * g_AppValue.precent,

  },
  thumbText:{
    fontSize:14 * g_AppValue.precent,
    color:'#9a9b9c',
    textAlign:'right',
  }
})
