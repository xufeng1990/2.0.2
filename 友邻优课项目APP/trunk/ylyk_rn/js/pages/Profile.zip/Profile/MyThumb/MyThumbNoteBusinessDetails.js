//  同学资料
//  功能: TODO 该类的作用
//  Created by 刘云强 on  2017
//  Copyright © 2017年  琢磨科技.

'use strict';
import React, { Component,} from 'react';
import {
  Text,
  View,
  Image,
  TextInput,
  ScrollView,
  ListView,
  StyleSheet,
  TouchableOpacity,
  TouchableHighlight,
  TouchableWithoutFeedback,
  Alert,
  NativeModules,
  DeviceEventEmitter
} from 'react-native';
//下拉刷新
import {
  SwRefreshScrollView,
  SwRefreshListView,
  RefreshStatus,
  LoadMoreStatus
} from 'react-native-swRefresh';
import * as ImgUrl from '../../../configs/BaseImgUrl.js';
import g_AppValue from '../../../configs/AppGlobal.js';
import *as RnNativeModules  from '../../../configs/RnNativeModules.js';
import Util from '../../../common/util.js';
import NoteCell from '../../../component/AlbumCell/noteCell.js';
const getFansById = NativeModules.NativeNetwork;
export default class MyThumbNoteBusinessDetails extends Component {
  // 构造函数
  _page=1
_dataSource = new ListView.DataSource({rowHasChanged:(row1,row2)=>row1 !== row2})
  _alldata = []//加载数组
  constructor(props) {
    super(props);
    this.state = {
        is_followee:this.props.nextfollowee,
        focusData:'',
        noteList:'',
        dataSource :this._dataSource.cloneWithRows(this._alldata),
        isShowLoadMore:false,
        thumbNumber:'',
    };
  }

  // 加载完成
  componentDidMount(){

    getFansById.getUserById(this.props.fansId + '')
    .then((data)=>{

      //console.log('data' + data)
      this.setState({
        focusData:JSON.parse(data)
      })

    }).catch((err)=>{
    //  console.log("数据错误...." + err)
    })
  this._onListRefersh();

  }

  _goToPlayerView(palyId){
    RnNativeModules.goToPlayerView( palyId +'');
  }

_goBack(){
  RnNativeModules.hideTabBar('show')
  this.props.navigator.pop()
}

// _thumChange(noteID,is_liked,rowID){
//     console.log('点赞状态' + is_liked);
// if (is_liked == true) {
//   return;
// }else {
//   getFansById.likeNote(noteID + '')
//   .then((data)=>{
//     //console.log("点赞成功" + data);
//       //console.log('点赞前数' + this.state.thumbNumber[rowID]);
//       var number = this.state.thumbNumber;
//       number[rowID] =(number[rowID] + 1);
//     this.setState({
//       thumbNumber: number,
//       dataSource :this._dataSource.cloneWithRows(this._alldata),
//     })
//       //console.log('点赞后数' + number[rowID])
//   }).catch((err)=>{
//     console.log("点赞失败" + err)
//   })
// }
//
//
// }


_focusStateAction(){
  var rowID = this.props.rowID;
  console.log('followeeArr1111111' + this.props.nextfollowee)
    //console.log('得到的rowID' + rowID)
  if (this.state.is_followee == true) {
      getFansById.deleteFollowee({'user_id': this.props.fansId + ''})
      .then((data) =>{
       console.log('取消' + data)
  //console.log('取消改变前状态' + this.state.is_followee)
      DeviceEventEmitter.emit('MyThumbNote',rowID);
      this.setState({
        is_followee:!this.state.is_followee,
      })
      //console.log('取消改变后状态' + this.state.is_followee)
      }).catch((err)=>{
        console.log("取消错误" + err)
      })
  }else {
    getFansById.createFollowee({'user_id': this.props.fansId + ''})
    .then((data) =>{
      console.log("关注成功" + data)
    DeviceEventEmitter.emit('MyThumbNote',rowID);
      //console.log('关注改变前状态' + this.state.is_followee)
      this.setState({
        is_followee:!this.state.is_followee,
      })
      //console.log('关注改变后状态' + this.state.is_followee)
    }).catch((err)=>{
      console.log("关注错误" + err)
    })
  }
}
_noteGotoPlay(){
  RnNativeModules.goToPlayerView(  '');
}


renderHeader(){
  if (!this.state.focusData) {
    return(<View></View>);
  }

  var focusData = this.state.focusData;
  // var palyId = focusData.course.id;
  return(
    <View style={styles.renderForegroundView}>
      <Image style={styles.bullyImage}/>
      <TouchableOpacity style={styles.leftImage} onPress={this._goBack.bind(this)}>
      <Image style={styles.leftImg} source= {require('../../Course/images/back1.png')} />
      </TouchableOpacity>
      <TouchableOpacity style={styles.rightImage} onPress={()=> this._goToPlayerView()}>
      <Image style={styles.rightImg} source= {require('../../Course/images/play.png')}/>
      </TouchableOpacity>

      <View style={styles.ForegroundView} >

        <TouchableOpacity>
        <Image style={styles.headerImage} source = {{uri:ImgUrl.baseImgUrl + 'user/' + this.props.fansId +'/avatar'}}/>
          </TouchableOpacity>

        <View style={styles.nameView}  >
          <Text style={styles.nameText}>{focusData.info.nickname} </Text>
            <Text style={{fontSize:14 *g_AppValue.precent,color:'#9a9b9c',marginTop:-2*g_AppValue.precent}}> | </Text>
              <Text style={{fontSize:11*g_AppValue.precent,color:'#9a9b9c',marginTop:3*g_AppValue.precent }}>24岁 · {this.state.focusData.info.city}</Text>

        </View>

        <View style = {styles.contentView} >
          <Text style={styles.contentText}>{focusData.info.intro}</Text>
        </View>


        <View style={styles.buttomView} >

          <View style={styles.FocusView}>
            <Text style={styles.numberText}>{focusData.stat.learned_time}</Text>
            <Text style={styles.FocusText} >学习时长/分钟</Text>
          </View>



          <View style={styles.FocusView}>
            <Text style={styles.numberText}>{focusData.stat.fans_count}</Text>
            <Text style={styles.FocusText} >粉丝</Text>
          </View>



          <View style={styles.FocusView}>
            <Text style={styles.numberText}>{focusData.stat.followee_count}</Text>
            <Text style={styles.FocusText} >关注</Text>
          </View>


        </View>
        <View style={styles.buttomOneView} >
          <TouchableOpacity onPress={()=>{this._focusStateAction()}}>

          <Text style={styles.FocusButtonImage}>{this.state.is_followee ? '已关注' : '关注'}</Text>
          </TouchableOpacity>


              <TouchableOpacity>
          <Image style={styles.weiXinButtonImage}/>
          </TouchableOpacity>
        </View>
      </View>
     </View>
  );
}
_rowRow(rowData,sectionID,rowID){

  var payId = rowData.course.id;
  var str = rowData.content;
  var   noteID = rowData.id;
  var is_liked = rowData.is_liked;
    var  st =str.replace(/<br>/g, '\n')

return(
  <NoteCell
    headPortraitImage = {{uri:ImgUrl.baseImgUrl + 'user/' + this.state.focusData.id +'/avatar'}}
    name = {this.state.focusData.info.nickname}
    time =  {Util.dateFormat(rowData.in_time,'yyyy-MM-dd')}
    content = {st}
    playImage = {{uri:ImgUrl.baseImgUrl + 'course/' + rowData.course.id +'/cover'}}
    playTitle = {rowData.course.name}
    playName = 'hehehehh'
    numberOfLines = {6}
    palyAction = {()=>this._noteGotoPlay(payId)}
    thumbNumber ={this.state.thumbNumber[rowID]}
    imagesData = {rowData.images}
    noteTouchInage = {() =>{this._noteTouchImages()}}

    />
);

}
  // render
  render(){


    if (!this.state.focusData && !this.state.noteList) {

      return(<View></View>)
    }

      var user_id = this.state.focusData.id;


    return (
      <View style={{flex:1,backgroundColor:'#ffffff'}}>

        <SwRefreshListView
          ref="listView"
          style={styles.listView}
          enableEmptySections={true}
          initialListSize = {5}
          dataSource={this.state.dataSource}
            isShowLoadMore={this.state.isShowLoadMore}
            onRefresh={this._onListRefersh.bind(this)}
            onLoadMore={this._onLoadMore.bind(this)}
          renderRow={this._rowRow.bind(this)}
          renderHeader={this.renderHeader.bind(this)}
          />
      </View>
    );
  }


  _onListRefersh(end){
    getFansById.getNoteList({'page':this._page,'limit':'5','user_id':this.props.fansId + ''})
  .then((data)=> {
  //  console.log("111111111111111111111111111" + data)
    var resultData = JSON.parse(data);
      //console.log('resultData' + resultData)
    let timer =  setTimeout(()=>{
      clearTimeout(timer)
    //  console.log("刷新成功 ")
        this._page ++
      for (let i = 0;i<resultData.length;i++){
        this._alldata.push(resultData[i])
      }
      this.setState({
        dataSource:this._dataSource.cloneWithRows(this._alldata),
        isShowLoadMore:true,
          thumbNumber: this._alldata.map((countN) =>{ return countN.like_count}),
      })
      if (resultData.length < 5) {
        this.refs.listView.setNoMoreData();
      }else {
        this.refs.listView.resetStatus() //重置上拉加载的状态
      }

        //end()
      //刷新成功后需要调用end结束刷新
       this.refs.listView.endRefresh() //建议使用end() 当然 这个可以在任何地方使用
    },1500)
  //end()
  }).catch((err)=> {
    console.warn('数据err', err);
  });
  }
  _onLoadMore(end){

    getFansById.getNoteList({'page':this._page,'limit':'10','user_id':this.props.fansId + ''})
  .then((data)=> {
    var resultData = JSON.parse(data);
    //  console.log('resultData333333333' + resultData)
      let timer =  setTimeout(()=>{
        clearTimeout(timer)
        this._page++

        for (let i = 0;i<resultData.length;i++){
          this._alldata.push(resultData[i])
        }
        //
        //console.log("加载成功")
        this.setState({
          dataSource:this._dataSource.cloneWithRows(this._alldata),
            thumbNumber: this._alldata.map((countN) =>{ return countN.like_count}),
        })

        end()//加载成功后需要调用end结束刷新 假设加载4页后数据全部加载完毕

      if (resultData.length < 10) {
        this.refs.listView.setNoMoreData()
      }else {
        this.refs.listView.endLoadMore()
      }


      },2000)
  }).catch((err)=> {
    console.warn('数据err', err);
  });


  }

}

var styles = StyleSheet.create({
  renderBackground:{
    width:g_AppValue.screenWidth,
    height:365 *g_AppValue.precent,
    backgroundColor:'#ffffff',
  },
  renderForegroundView:{
    height:365 *g_AppValue.precent,
      backgroundColor:'#ffffff',

  },
  leftImage:{
    width:10  *g_AppValue.precent,
    height:18  *g_AppValue.precent,
  },
  leftImg:{
    position:'absolute',
    top:34  *g_AppValue.precent,
    left:13  *g_AppValue.precent,
    width:10  *g_AppValue.precent,
    height:18  *g_AppValue.precent,
  },
  rightImage:{
    position:'absolute',
    top:31  *g_AppValue.precent,
    right:14  *g_AppValue.precent,
    width:24  *g_AppValue.precent,
    height:24  *g_AppValue.precent,
  },
  rightImg:{
    width:24  *g_AppValue.precent,
    height:24  *g_AppValue.precent,
  },


  ForegroundView:{
    width:g_AppValue.screenWidth,
    height:285  *g_AppValue.precent,
  //  backgroundColor:'red',
    marginTop:60  *g_AppValue.precent,
    alignItems:'center',

  },
  headerImage:{
    width:77  *g_AppValue.precent,
    height:77  *g_AppValue.precent,
    borderRadius:38.5*g_AppValue.precent


  },
  nameView:{
    width:g_AppValue.screenWidth,
    height:16  *g_AppValue.precent,
    marginTop:8  *g_AppValue.precent,
  //  backgroundColor:'red',
    justifyContent:'center',
    flexDirection:'row'
  },
  nameText:{
    fontSize:14  *g_AppValue.precent,
    color:'#5a5a5a',
    textAlign:'center',
    fontWeight:'bold',

  },

  contentView:{
    width:218  *g_AppValue.precent,
    height:26  *g_AppValue.precent,
  //  backgroundColor:'green',
    justifyContent:'center',
    alignItems:'center',
    marginTop:10  *g_AppValue.precent,
  },
  contentText:{
    fontSize:11  *g_AppValue.precent,
    color:'#9a9b9c',
    textAlign:'center',
  },
  buttomView:{
    width:g_AppValue.screenWidth,
    //backgroundColor:'yellow',
    marginTop:22  *g_AppValue.precent,
    flexDirection:'row',
    justifyContent:'space-around',


  },
  FocusView:{
  //backgroundColor:'green',
  alignItems:'center',
},
numberText:{
  fontSize:16  *g_AppValue.precent,
  color:'#5a5a5a',

},
FocusText:{
  fontSize:11  *g_AppValue.precent,
  color:'#9a9b9c',
   marginTop:6  *g_AppValue.precent,
},
bullyImage:{
  position:'absolute',
  width:57 *g_AppValue.precent,
  height:23 *g_AppValue.precent,
  top:105 *g_AppValue.precent,
  right:0 *g_AppValue.precent,
  backgroundColor:'red',
},
buttomOneView:{
  width:g_AppValue.screenWidth,
  height:35 *g_AppValue.precent,
//  backgroundColor:'black',
  marginTop:30 *g_AppValue.precent,
  marginBottom:30 *g_AppValue.precent,
  flexDirection:'row',
},
FocusButtonImage:{
  width:116 *g_AppValue.precent,
  height:36 *g_AppValue.precent,
  backgroundColor:'green',
  marginLeft:55 *g_AppValue.precent,
},
weiXinButtonImage:{
  width:116 *g_AppValue.precent,
  height:36 *g_AppValue.precent,
  backgroundColor:'green',
  marginLeft:34 *g_AppValue.precent,
}

});
