//  NoteDetails
//  功能: TODO 该类的作用
//  Created by 刘云强 on  2016-10-20
//  Copyright © 2017年  琢磨科技.

'use strict';
import React, { Component,} from 'react';
import {
  Text,
  View,
  Image,
  TextInput,
  ScrollView,
  ListView,
  StyleSheet,
  TouchableOpacity,
  TouchableHighlight,
  TouchableWithoutFeedback,
  Alert,
  NativeModules,
  DeviceEventEmitter,
} from 'react-native';

import {
  SwRefreshScrollView,
  SwRefreshListView,
  RefreshStatus,
  LoadMoreStatus
} from 'react-native-swRefresh';
import Util from '../../../common/util.js';
import NoteCell from '../../../component/AlbumCell/noteCell.js';
import * as ImgUrl from '../../../configs/BaseImgUrl.js';
import g_AppValue from '../../../configs/AppGlobal.js';
import *as RnNativeModules from '../../../configs/RnNativeModules.js';
import MyThumbNoteBusinessDetails from './MyThumbNoteBusinessDetails.js';
const getMyThumbNoteList = NativeModules.NativeNetwork;
export default class MyThumbNoteDetails extends Component {
  // 构造函数
  _page=1
  _dataSource = new ListView.DataSource({rowHasChanged:(row1,row2)=>row1 !== row2})
  _alldata = []//加载数组
  _followeeArr = [];//点赞数组
  constructor(props) {
    super(props);
    this.state = {
      dataSource :this._dataSource.cloneWithRows(this._alldata),
      isShowLoadMore:false,
      thumbNumber:this.props.thumbNumber,
    };
  }

  // 加载完成
  componentDidMount(){
  }

  // view卸载
  componentWillUnmount(){
    //
  }
  _noteGotoPlay(payId){
    RnNativeModules.goToPlayerView(payId + '')
  }
  _goBack(){
    RnNativeModules.hideTabBar('show');
    this.props.navigator.pop();

  }

  _thumChange(noteID,is_liked,rowID){
      // console.log('点赞状态' + is_liked);
  if (is_liked == true) {
    return;
  }else {
    getALLNoteList.likeNote(noteID + '')
    .then((data)=>{
      DeviceEventEmitter.emit('noteID',rowID);
      this.setState({
        thumbNumber: this.state.thumbNumber + 1,
        dataSource :this._dataSource.cloneWithRows(this._alldata),
      })

    }).catch((err)=>{
      console.log("点赞失败" + err)
    })
  }


  }

  _Business(nextfollowee,rowID){
    console.log('详情传rowID' + rowID)
    this.props.navigator.push({
      component:MyThumbNoteBusinessDetails,
      params:{
        fansId:this.props.fansId,
        nextfollowee:nextfollowee,
        rowID:rowID,
      }
    })
  }
  //  focusChangeImage = {this.state.is_followee[rowID] ? require('../Course/images/Focus2.png') :require('../Course/images/Focus1.png')}

  // render
  render(){
    var str = this.props.rowData.content;
      var  st =str.replace(/<br>/g, '\n')
      var payId = this.props.rowData.course.id;
      var nextfollowee = this.props.nextfollowee;
      var rowID = this.props.rowID;
      var   noteID = this.props.rowData.id;
      var is_liked = this.props.rowData.is_liked;

    return (
      <View style={styles.container} >
        <View style={styles.headerView}>
          <View style={styles.headerContentView} >
            <TouchableOpacity style = {styles.backButtomA} onPress={()=>{this._goBack()}}>
          <Image style={styles.backButtom} />
              </TouchableOpacity>
              <Text style={styles.headerTitle}>心得详情</Text>
              <TouchableOpacity style = {styles.gotoPalyButtomA}>
                  <Image style={styles.gotoPalyButtom}/>
                </TouchableOpacity>
          </View>
        </View>
        <ScrollView>

        <NoteCell
          headPortraitImage = {{uri:ImgUrl.baseImgUrl + 'user/' +this.props.rowData.user.id +'/avatar'}}
          headerImageAction = {()=>{this._Business(nextfollowee,rowID)}}
          name = {this.props.rowData.user.nickname}
          time = {Util.dateFormat(this.props.rowData.in_time,'yyyy-MM-dd')}
          content = {st}
          playImage = {{uri:ImgUrl.baseImgUrl + 'course/' + this.props.rowData.course.id +'/cover'}}
          playTitle = {this.props.rowData.course.name}
          playName = 'hehehehh'
          palyAction = {()=>this._noteGotoPlay(payId)}
          foucsActionFnc = {()=>{this._foucsAction(rowData,sectionID,rowID)}}
          thumActionFnc = {()=>{this._thumChange(noteID,is_liked,rowID)}}
          thumbNumber ={this.props.rowData.like_count}
          imagesData = {this.props.rowData.images}
            />
          </ScrollView>
      </View>
    );
  }



}

var styles = StyleSheet.create({
  container:{
    flex:1,
    backgroundColor:'#ffffff'
  },
  headerView:{
    width:g_AppValue.screenWidth,
    height:64*g_AppValue.precent,
    //backgroundColor:'red',

  },
  headerContentView:{
    width:g_AppValue.screenWidth,
    height:24*g_AppValue.precent,
  //  backgroundColor:'yellow',
    marginTop:31*g_AppValue.precent,
    justifyContent:'center',
    alignItems:'center',
  },
  headerTitle:{
    fontSize:18*g_AppValue.precent,
    color:'#5a5a5a',
  },
  backButtomA:{
    position:'absolute',
    width:10*g_AppValue.precent,
    height:18*g_AppValue.precent,
    left:12*g_AppValue.precent,
  },
  backButtom:{
    width:10*g_AppValue.precent,
    height:18*g_AppValue.precent,
    backgroundColor:'black',

  },
  gotoPalyButtomA:{
    position:'absolute',
    width:24*g_AppValue.precent,
    top:-1*g_AppValue.precent,
    height:24*g_AppValue.precent,
    right:11*g_AppValue.precent,
right:11*g_AppValue.precent,
  },
  gotoPalyButtom:{
    width:24*g_AppValue.precent,
    height:24*g_AppValue.precent,
    backgroundColor:'black',

  }
})
