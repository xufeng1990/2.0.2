//  AlbumNote
//  功能: TODO 该类的作用
//  Created by 刘云强 on  2016-10-20
//  Copyright © 2017年  琢磨科技.

'use strict';
import React, { Component,} from 'react';
import {
  Text,
  View,
  Image,
  TextInput,
  ScrollView,
  ListView,
  StyleSheet,
  TouchableOpacity,
  TouchableHighlight,
  TouchableWithoutFeedback,
  Alert,
  NativeModules,
  DeviceEventEmitter
} from 'react-native';
import {
  SwRefreshScrollView,
  SwRefreshListView,
  RefreshStatus,
  LoadMoreStatus
} from 'react-native-swRefresh'
import Util from '../../../common/util.js';
import * as ImgUrl from '../../../configs/BaseImgUrl.js';
import g_AppValue from '../../../configs/AppGlobal.js';
import NoteCell from '../../../component/AlbumCell/noteCell.js';
import *as RnNativeModules from '../../../configs/RnNativeModules.js';
import MyThumbNoteDetails from './MyThumbNoteDetails.js';
import MyThumbNoteBusinessDetails from './MyThumbNoteBusinessDetails.js';
const  thumbNoteList = NativeModules.NativeNetwork;
export default class MyThumbNote extends Component {
  // 构造函数
  _page = 1;
    _dataSource = new ListView.DataSource({rowHasChanged:(row1,row2)=>row1 !== row2})
_alldata =[];
_followeeArr =[];
  constructor(props) {
    super(props);
    this.state = {
      dataSource : this._dataSource.cloneWithRows(this._alldata),
      isShowLoadMore:false,
      is_followee:this._followeeArr,
    };
  }


  // 加载完成
  componentDidMount(){
        DeviceEventEmitter.addListener('MyThumbNote',(rowID)=>{
          //
          //console.log("接搜通知")
          var arr  = this.state.is_followee;
          arr[rowID] = !arr[rowID];
       this.setState({
        is_followee:arr,
         dataSource :this._dataSource.cloneWithRows(this._alldata),

       })

        });
   this.refs.listView.endRefresh()
    this._onListRefersh();
  }
  _noteGotoPlay(playID){
RnNativeModules.goToPlayerView(playID + '')
  }

  // view卸载
  componentWillUnmount(){

  }
  _foucsAction(rowData,sectionID,rowID){

    if (this.state.is_followee == true) {
          thumbNoteList.deleteFollowee({'user_id':  rowData.user.id + ''})
          .then((data) =>{

            var followeeArr = this.state.is_followee;
            followeeArr[rowID] = !followeeArr[rowID];

            this.setState({
              is_followee:followeeArr,
              dataSource :this._dataSource.cloneWithRows(this._alldata),
            })

          }).catch((err)=>{
            console.log("取消错误" + err)
          })
    }else {
        thumbNoteList.createFollowee({'user_id': rowData.user.id + ''})
        .then((data) =>{
        console.log('关注成功' + data)
      //  DeviceEventEmitter.emit('refreshData',rowData.user.id);
        var FocusFollowee = this.state.is_followee;

        FocusFollowee[rowID] = !FocusFollowee[rowID];
        this.setState({
          is_followee:FocusFollowee,
          dataSource :this._dataSource.cloneWithRows(this._alldata),
        })

          }).catch((err)=>{
            console.log("关注错误" + err)
          })
    }
  }
  _renderItem(item){
    return(
      <TouchableOpacity style = {styles.imageItem}>

      <Image style={styles.imageItem} source= {{uri:item}}/>

    </TouchableOpacity>
    );
  }
  _goToDetailsView(fansId,nickname,rowData,nextfollowee,rowID){
    this.props.navigator.push({
      component:MyThumbNoteDetails,
      params:{
        fansId:fansId,
        nickname:nickname,
        rowData:rowData,
        nextfollowee:nextfollowee,
        rowID:rowID,

      }
    })
  }

  _renderHeaderAction(fansId,rowID){
    //  var   thumbNumber   = this.state.thumbNumber[rowID];
    var nextfollowee = this.state.is_followee[rowID];
    RnNativeModules.hideTabBar('hide');
    this.props.navigator.push({
      component:MyThumbNoteBusinessDetails,
      params:{
        fansId:fansId,
        nextfollowee:nextfollowee,
        rowID:rowID,
      //  thumbNumber:thumbNumber,
      }
    })
  }

  _rowRow(rowData,sectionID,rowID){
    var playID = rowData.course.id;
    var str = rowData.content;
  //  console.log('关注状态' + this.state.is_followee)
      var  st =str.replace(/<br>/g, '\n')
      var fansId = rowData.user.id;
      var nickname =rowData.user.nickname;
        var nextfollowee = this.state.is_followee[rowID];

  return(
    <TouchableOpacity onPress={()=> {this._goToDetailsView(fansId,nickname,rowData,nextfollowee,rowID)}}>
    <NoteCell
        headerImageAction = {()=>this._renderHeaderAction(fansId,rowID)}
      headPortraitImage = {{uri:ImgUrl.baseImgUrl + 'user/' + rowData.user.id +'/avatar'}}
      name = {rowData.user.nickname}
      time = {Util.dateFormat(rowData.in_time,'yyyy-MM-dd')}
      content = {st}
      playImage = {{uri:ImgUrl.baseImgUrl + 'course/' + rowData.course.id +'/cover'}}
      playTitle = {rowData.course.name}
      playName = 'hehehehh'
      numberOfLines = {6}
      palyAction = {()=>this._noteGotoPlay(playID)}
      thumbNumber ={rowData.like_count}
      foucsActionFnc = {()=>{this._foucsAction(rowData,sectionID,rowID)}}
      focusChangeImage = {this.state.is_followee[rowID] ? require('../../Course/images/Focus2.png') :require('../../Course/images/Focus1.png')}
      thumActionFnc = {()=>{this._thumChange(noteID,is_liked,rowID)}}
      imagesData = {rowData.images}
      />
      </TouchableOpacity>
  );
  }
  // render
  render(){

    return (
      <View style ={{flex:1}}>

          <SwRefreshListView
            ref = 'listView'
            style={styles.listView}
            enableEmptySections={true}
            dataSource={this.state.dataSource}
            renderRow={this._rowRow.bind(this)}
            onRefresh={this._onListRefersh.bind(this)}
            onLoadMore={this._onLoadMore.bind(this)}
            isShowLoadMore={this.state.isShowLoadMore}
            />
      </View>

    );
  }

  _onListRefersh(end){
    thumbNoteList.getNoteList({'is_liked':'true','limit':'5',page:this._page,})
    .then((data) =>{
    //  console.log('data' + data)
      var resultData = JSON.parse(data);
    let timer =  setTimeout(()=>{
      clearTimeout(timer)
      //console.log("刷新成功 ")
        this._page ++
      for (let i = 0;i<resultData.length;i++){
        this._alldata.push(resultData[i]);
        thumbNoteList.getUserById(resultData[i].user.id + '')
        .then((data) =>{
          var userByIdDate = JSON.parse(data)
          //console.log("获取状态数据" + data)
          this._followeeArr.push(userByIdDate.is_followee);
          //  console.log('关注' + this._followeeArr)
        }).catch((err)=>{
          console.log('数据错误' + err);
        })
      }
      this.setState({
        dataSource : this._dataSource.cloneWithRows(this._alldata),
        isShowLoadMore:true,
        is_followee:this._followeeArr,
      })
        //end()
      if (resultData.length < 5) {
        this.refs.listView.setNoMoreData();
      }else {
        this.refs.listView.resetStatus() //重置上拉加载的状态
      }


      //刷新成功后需要调用end结束刷新
      this.refs.listView.endRefresh() //建议使用end() 当然 这个可以在任何地方使用
    },1500)

  //end()
  }).catch((err)=> {
    console.warn('数据err', err);
  });
  }
  _onLoadMore(end){

    thumbNoteList.getNoteList({'is_liked':'true','limit':'10',page:this._page,})
    .then((data) =>{
    //  console.log('data' + data)
      var resultData = JSON.parse(data);
      let timer =  setTimeout(()=>{
        clearTimeout(timer)
        this._page++
        for (let i = 0;i<resultData.length;i++){
          this._alldata.push(resultData[i]);
          thumbNoteList.getUserById(resultData[i].user.id + '')
          .then((data) =>{
            var userByIdDate = JSON.parse(data)
          //  console.log("获取状态数据" + data)
            this._followeeArr.push(userByIdDate.is_followee);

          }).catch((err)=>{
            console.log('数据错误' + err);
          })
        }
        this.setState({
          dataSource:this._dataSource.cloneWithRows(this._alldata),
          is_followee:this._followeeArr,

        })
      //  let isNoMore = this._page > 2 //是否已无更多数据
     //结束
     //end(isNoMore)// 假设加载4页后


      if (resultData.length < 10) {
        this.refs.listView.setNoMoreData();
      }else {
        this.refs.listView.endLoadMore()
      }

          end()//加载成功后需要调用end结束刷新 假设加载4页后数据全部加载完毕
    //this.refs.listView.setNoMoreData();

      },2000)
  }).catch((err)=> {
    console.warn('数据err', err);
  });


  }

}
var styles = StyleSheet.create({
  listView:{
    flex:1,
    backgroundColor:'#f2f5f6',
  },
  container:{
    flex:1,
     width:g_AppValue.screenWidth,
    backgroundColor:'#ffffff',
    marginTop:10 * g_AppValue.precent,
    flexDirection:'row',

  },
  HeadPortraitImage:{
    width:39 * g_AppValue.precent,
    height:39 * g_AppValue.precent,
    marginTop:12 * g_AppValue.precent,
    marginLeft:12 * g_AppValue.precent,

  },
  FocusImage:{
    width:54 * g_AppValue.precent,
    height:21 * g_AppValue.precent,
    position:'absolute',
    top:0 * g_AppValue.precent,
    right:12 * g_AppValue.precent,

  },
  rightBigView:{
    flex:1,
    width:295 * g_AppValue.precent,
    //backgroundColor:'green',
    marginTop:17 * g_AppValue.precent,
    marginLeft:10 * g_AppValue.precent,
  },
  nameText:{
    width:200 * g_AppValue.precent,
    fontSize:14 * g_AppValue.precent,
    color:'#5a5a5a',
    textAlign:'left',
  },
  timeText:{
      width:200 * g_AppValue.precent,
    marginTop:5 * g_AppValue.precent,
    fontSize:11 * g_AppValue.precent,
    color:'#9a9b9c',
    textAlign:'left',
  },
  contentText:{
    width:295 * g_AppValue.precent,
    marginTop:8 * g_AppValue.precent,
    fontSize:13 * g_AppValue.precent,
    color:'#5a5a5a',
    textAlign:'left',
  },
  ImageView:{
    flex:1,
    width:294 * g_AppValue.precent,
    marginLeft:-20 * g_AppValue.precent,
    flexWrap:'wrap',
    flexDirection:'row',
  },
  imageItem:{
    width:88* g_AppValue.precent,
    height:88 * g_AppValue.precent,
    marginTop:10 * g_AppValue.precent,
    marginLeft:10 * g_AppValue.precent,
  },
  payView:{
    marginTop:20 * g_AppValue.precent,
    width:284 * g_AppValue.precent,
    height:48 * g_AppValue.precent,
    flexDirection:'row',

  },
  payImageOne:{
    width:64 * g_AppValue.precent,
    height:48 * g_AppValue.precent,

  },
  payImageTwo:{
    position:'absolute',
    top:0 * g_AppValue.precent,
    width:64 * g_AppValue.precent,
    height:48 * g_AppValue.precent,
  },
  payRightView:{
    marginLeft:10 * g_AppValue.precent,
    width:210 * g_AppValue.precent,
    height:48 * g_AppValue.precent,
  },
  payRightTitleText:{
    marginTop:8 * g_AppValue.precent,
    fontSize:13 * g_AppValue.precent,
    color:'#5a5a5a',
    textAlign:'left',
  },
  payRightNameText:{
    marginTop:4 * g_AppValue.precent,
    fontSize:12 * g_AppValue.precent,
    color:'#5a5a5a',
    textAlign:'left',
  },
  ThumbView:{
    flex:1,
    height:16 * g_AppValue.precent,
    marginTop:15 * g_AppValue.precent,
    marginBottom:14 * g_AppValue.precent,
    marginRight:12* g_AppValue.precent,
    justifyContent:'flex-end',
    flexDirection:'row',

  },
  thumbImage:{
    width:16 * g_AppValue.precent,
    height:16 * g_AppValue.precent,
    marginRight:6 * g_AppValue.precent,

  },
  thumbText:{
    fontSize:14 * g_AppValue.precent,
    color:'#9a9b9c',
    textAlign:'right',
  }
})
