//  "NewClass"
//  功能: TODO 该类的作用
//  Created by 刘云强 on  2016-10-20
//  Copyright © 2017年  琢磨科技.

'use strict';
import React, { Component,} from 'react';
import {
  Text,
  View,
  Image,
  TextInput,
  ScrollView,
  ListView,
  StyleSheet,
  TouchableOpacity,
  TouchableHighlight,
  TouchableWithoutFeedback,
  Alert,
  NativeModules,
} from 'react-native';
import g_AppValue from '../../../configs/AppGlobal.js';
// 类
import {
  SwRefreshScrollView,
  SwRefreshListView,
  RefreshStatus,
  LoadMoreStatus
} from 'react-native-swRefresh';
const getLikeCourseList = NativeModules.NativeNetwork;
export default class MyThumbShow extends Component {
  // 构造函数
  _page = 1;
    _dataSource = new ListView.DataSource({rowHasChanged:(row1,row2)=>row1 !== row2})
_alldata =[1,2,3,4,5];
_followeeArr =[];
  constructor(props) {
    super(props);
    this.state = {
      dataSource:this._dataSource.cloneWithRows(this._alldata),
      isShowLoadMore:false,
      //  is_followee:this._followeeArr,
  }
}
  // 加载完成
  componentDidMount(){
this._onListRefersh();
  }

  // view卸载
  componentWillUnmount(){
    //
  }
  _rowRow(){
    return(
      <TouchableOpacity>
      <View  style={styles.backgroundView}>
          <Image  source = {require('../../Course/images/f.png')} style = {styles.leftImage}/>
          <View style={styles.rightBigView}>
            <Text style={styles.titleText} >节目一</Text>
            <Text style={styles.contentText}>＃大品牌背后的小故事</Text>
            <Text style={styles.teacherNameText} >刘云强</Text>
            <View style={styles.bottomView}>
              <Text style={styles.timeText} >14233</Text>
              <Text  style={styles.bigText} >30MB</Text>

            </View>

          </View>

      </View>
    </TouchableOpacity>
    );
  }

  // render
  render(){


    return (
      <View style ={{flex:1}}>
        <SwRefreshListView
          ref = 'listView'
          style={styles.listView}
          enableEmptySections={true}
          dataSource={this.state.dataSource}
          renderRow={this._rowRow.bind(this)}
          enableEmptySections={true}
          onRefresh={this._onListRefersh.bind(this)}
          onLoadMore={this._onLoadMore.bind(this)}
            isShowLoadMore={this.state.isShowLoadMore}
          />

      </View>

    );
  }

  _onListRefersh(end){
    getLikeCourseList.getCourseList({'is_liked':'true','limit':'5',page:this._page,})
    .then((data) =>{
      console.log('data======' + data)
      var resultData = JSON.parse(data);
    let timer =  setTimeout(()=>{
      clearTimeout(timer)
      //console.log("刷新成功 ")
        this._page ++
      for (let i = 0;i<resultData.length;i++){
        this._alldata.push(resultData[i]);
      //   thumbNoteList.getUserById(resultData[i].user.id + '')
      //   .then((data) =>{
      //     var userByIdDate = JSON.parse(data)
      //     //console.log("获取状态数据" + data)
      //     this._followeeArr.push(userByIdDate.is_followee);
      //     //  console.log('关注' + this._followeeArr)
      //   }).catch((err)=>{
      //     console.log('数据错误' + err);
      //   })
       }
      this.setState({
        dataSource : this._dataSource.cloneWithRows(resultData),
        isShowLoadMore:true,
        //is_followee:this._followeeArr,
      })
        //end()
      if (resultData.length < 5) {
        this.refs.listView.setNoMoreData();
      }else {
        this.refs.listView.resetStatus() //重置上拉加载的状态
      }


      //刷新成功后需要调用end结束刷新
      this.refs.listView.endRefresh() //建议使用end() 当然 这个可以在任何地方使用
    },1500)

  //end()
  }).catch((err)=> {
    console.warn('数据err', err);
  });
  }
  _onLoadMore(end){

    getLikeCourseList.getCourseList({'is_liked':'true','limit':'10',page:this._page,})
    .then((data) =>{
    //  console.log('data' + data)
      var resultData = JSON.parse(data);
      let timer =  setTimeout(()=>{
        clearTimeout(timer)
        this._page++
        for (let i = 0;i<resultData.length;i++){
          this._alldata.push(resultData[i]);
          // thumbNoteList.getUserById(resultData[i].user.id + '')
          // .then((data) =>{
          //   var userByIdDate = JSON.parse(data)
          // //  console.log("获取状态数据" + data)
          //   this._followeeArr.push(userByIdDate.is_followee);
          //
          // }).catch((err)=>{
          //   console.log('数据错误' + err);
          // })
        }
        this.setState({
          dataSource:this._dataSource.cloneWithRows(this._alldata),
        //  is_followee:this._followeeArr,

        })
      //  let isNoMore = this._page > 2 //是否已无更多数据
     //结束
     //end(isNoMore)// 假设加载4页后


      if (resultData.length < 10) {
        this.refs.listView.setNoMoreData();
      }else {
        this.refs.listView.endLoadMore()
      }

          end()//加载成功后需要调用end结束刷新 假设加载4页后数据全部加载完毕
    //this.refs.listView.setNoMoreData();

      },2000)
  }).catch((err)=> {
    console.warn('数据err', err);
  });


  }

}
var styles = StyleSheet.create({
  container:{
    flex:1,
    backgroundColor:'#f2f5f6',

  },
  listView:{
    backgroundColor:'#f2f5f6'
  },
  backgroundView:{
    height:110 * g_AppValue.precent,
    width:g_AppValue.screenWidth,
    marginTop:10 * g_AppValue.precent,
    backgroundColor:'#ffffff',
    flexDirection:'row',
  },
  leftImage:{
    width:120 * g_AppValue.precent,
    height:90 * g_AppValue.precent,
    marginTop:10 * g_AppValue.precent,
    marginLeft:13 * g_AppValue.precent,
  },
  rightBigView:{
    marginLeft:15 * g_AppValue.precent,
    marginTop:17 * g_AppValue.precent,
    width:206 * g_AppValue.precent,
    height:83 * g_AppValue.precent,
  //  backgroundColor:'red',
  },
  titleText:{
    fontSize:14 * g_AppValue.precent,
    fontWeight:'bold',
    color:'#5a5a5a',
  },
  teacherNameText:{
    fontSize:11 * g_AppValue.precent,
    color:'#9a9b9c',
    marginTop:4 * g_AppValue.precent,
  },
  timeText:{
    fontSize:11 * g_AppValue.precent,
    color:'#9a9b9c',

  },
contentText:{
  fontSize:13 * g_AppValue.precent,
  marginTop:17 * g_AppValue.precent,
  color:'#5a5a5a',
},
bottomView:{
  width:200 * g_AppValue.precent,
  //backgroundColor:'yellow',
  flexDirection:'row',
  marginTop:4 * g_AppValue.precent,
},
bigText:{
  fontSize:11 * g_AppValue.precent,
  color:'#9a9b9c',
  marginLeft:5 * g_AppValue.precent,
},

})
