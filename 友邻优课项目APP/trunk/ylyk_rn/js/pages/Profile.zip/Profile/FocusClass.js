//  FoucsClass
//  功能: TODO 该类的作用
//  Created by 刘云强 on  2016-10-20
//  Copyright © 2017年  琢磨科技.

'use strict';
import React, { Component,} from 'react';
import {
  Text,
  View,
  Image,
  TextInput,
  ScrollView,
  ListView,
  StyleSheet,
  TouchableOpacity,
  TouchableHighlight,
  TouchableWithoutFeedback,
  Alert,
  NativeModules,
  DeviceEventEmitter
} from 'react-native';
import * as ImgUrl from '../../configs/BaseImgUrl.js';
import NavigationBar from '../../component/Navigator/NavigationBar.js';
import g_AppValue from '../../configs/AppGlobal.js';
import ProfileRowCell from '../../component/AlbumCell/ProfileRowCell.js'
import *as RnNativeModules  from '../../configs/RnNativeModules.js';
import FocusInformation from './focusInformation.js';

const getFolloweeList = NativeModules.NativeNetwork;
// 类
export default class FoucsClass extends Component {
  // 构造函数
  constructor(props) {
    super(props);
    this.focus = true
    this.state = {
      //初始状态
   FoucsState:this.props.FoucsData.map((item) =>{return item.is_followee}),
    FoucsData:this.props.FoucsData,
    };
  }

_goBack(){
  var user_id = this.props.user_id;
    DeviceEventEmitter.emit('refreshData',user_id);
  RnNativeModules.hideTabBar('show')
  this.props.navigator.pop();
}


componentDidMount(){
  this.changeFousId = DeviceEventEmitter.addListener('changeFousId',(rowID)=>{
    //console.log('更新前的' + this.state.FoucsState)
    var arr = this.state.FoucsState;
      arr[rowID] = !arr[rowID];
   this.setState({
     FoucsState:arr,
   })
  // console.log('更新后的' + arr)
  })
  getFolloweeList.getFolloweeList({'page':1,'user_id':this.props.user_id})
  .then((data)=>{
  //  console.log('data' + data);
    this.setState({FoucsData:JSON.parse(data)})
  }).catch((err)=>{
    console.log('数据错误..' + err)
  })
}
componentWillUnmount(){
  this.changeFousId && this.changeFousId.remove();
}

_focusAction(rowData,sectionID,rowID){

  if (this.state.FoucsState[rowID] == true) {
    getFolloweeList.deleteFollowee({'user_id':rowData.user.id})
    .then(()=>{
      //console.log('取消成功')
        delete this.state.FoucsData[rowID];

          this.setState({
        FoucsData: this.state.FoucsData,
      })

    }).catch((err)=>{
      console.log('取消失败' + err)
    })
  }else {
    getFolloweeList.createFollowee({'user_id':rowData.user.id })
    .then((data) =>{
      var arr = this.state.FoucsState;
    //  console.log('更新前的数组' + this.state.FoucsState)

        arr[rowID] = !arr[rowID]
      this.setState({
        FoucsState:arr,
      })
    //  console.log("更新后的数组" + this.state.FoucsState)

    }).catch((err)=>{
      console.log("关注失败" + err)
    })
  }

}

_goToInformationPage(focusId,is_followee,rowID){

  this.props.navigator.push({
    component:FocusInformation,
    params:{
      focusId:focusId,
      is_followee:is_followee,
      rowID:rowID,
    }
  })
}
_renderRow(rowData,sectionID,rowID){

  var focusId = rowData.user.id;
  var is_followee = rowData.is_followee;

  return(
    <TouchableOpacity onPress={() =>{this._goToInformationPage(focusId,is_followee,rowID)}}>

      <ProfileRowCell
        name = {rowData.user.nickname}
        headerImage = {{uri:ImgUrl.baseImgUrl + 'user/' + rowData.user.id +'/avatar'}}
        contentText = {rowData.user.intro}
        focusImagePath = {this.state.FoucsState[rowID] ? require('../Course/images/Focus2.png' ): require('../Course/images/Focus1.png')}
        foucsActionFnc = {() => {this._focusAction(rowData,sectionID,rowID)}}
        />
          </TouchableOpacity>
  );
}
  // render
  render(){
    if (!this.state.FoucsData) {
      return(<View></View>);
    }
    //console.log('初始状态数组' + this.state.FoucsState)
  var data = this.state.FoucsData;
  var ds = new ListView.DataSource({rowHasChanged: (r1,r2) => r1 !== r2});
  var dataSource = ds.cloneWithRows(data);

    return (
      <View style={styles.container}>
      <View style={styles.headerView}>
        <Text style={styles.titleText} >关注</Text>
        <TouchableOpacity  style={styles.touchBackImage}  onPress={this._goBack.bind(this)}>
        <Image style={styles.backImage} source= {require('../Course/images/back1.png')} />
            </TouchableOpacity>
      </View>

      <ListView
        ref = 'scrollView'
        enableEmptySections={true}
        dataSource={dataSource}
        renderRow={this._renderRow.bind(this)}
        removeClippedSubviews={false}
        />
        </View>
    );
  }

  // 自定义方法区域
  // your method
  // leftItemFunc = {this._leftItemAction.bind(this)}

}

var styles = StyleSheet.create({
  container:{
    flex:1,
    backgroundColor:'#f2f5f6',
  },
  headerView:{
    width:g_AppValue.screenWidth,
    height:65 * g_AppValue.precent,
    alignItems:'center',
    backgroundColor:'#ffffff',
  },
  titleText:{
    marginTop:34 * g_AppValue.precent,
    fontSize:18 * g_AppValue.precent,
    color:'#5a5a5a',
  },
  touchBackImage:{
    position:'absolute',
    top:33 * g_AppValue.precent,
    left:12 * g_AppValue.precent,
  },
  backImage:{
    width:10 * g_AppValue.precent,
    height:18 * g_AppValue.precent,
  },
  rowView:{
    width:g_AppValue.screenWidth,
    height:82 * g_AppValue.precent,
    backgroundColor:'#ffffff',
    marginTop:10 * g_AppValue.precent,
    flexDirection:'row',
  },
  headerImage:{
    width:58 * g_AppValue.precent,
    height:58 * g_AppValue.precent,
    marginTop:15 * g_AppValue.precent,
    marginLeft:12 * g_AppValue.precent,
  },
  cintentView:{
    width:200 * g_AppValue.precent,
    height:35 * g_AppValue.precent,
    // backgroundColor:'red',
    marginLeft:12 * g_AppValue.precent,
    marginTop:25 * g_AppValue.precent,
  },
  nameText:{
    fontSize:14 * g_AppValue.precent,
    color:'#5a5a5a',
  },
  introduceText:{
    fontSize:11 * g_AppValue.precent,
    color:'#9a9b9c',
    marginTop:8 * g_AppValue.precent,
  },
  touchFocusImage:{
  //  backgroundColor:'black',
    position:'absolute',
    top:31 * g_AppValue.precent,
    right:12 * g_AppValue.precent,
    bottom:30 * g_AppValue.precent,
  },
  focusImage:{
    width:54 * g_AppValue.precent,
    height:21 * g_AppValue.precent,

  }

})
