//  "ProgileTabBar"
//  功能: TODO 该类的作用
//  Created by 刘云强 on  2017
//  Copyright © 2017年  琢磨科技.

'use strict';
import React, { Component,} from 'react';
import {
  Text,
  View,
  Image,
  TextInput,
  ScrollView,
  ListView,
  StyleSheet,
  TouchableOpacity,
  TouchableHighlight,
  TouchableWithoutFeedback,
  Alert,
  NativeModules,
  DeviceEventEmitter
} from 'react-native';
import * as ImgUrl from '../../configs/BaseImgUrl.js';
import NavigationBar from '../../component/Navigator/NavigationBar.js';
import g_AppValue from '../../configs/AppGlobal.js';
import Child from '../../component/tabs/Qasd.js';
import MyDownload from './MyDownload.js'
import ProfileView from './ProfileView.js';
import *as RnNativeModules  from '../../configs/RnNativeModules.js';
import MyFans from './MyFans.js';
import FoucsClass from './FocusClass.js';
import MyNoteList from './MyNoteList.js';
const getUserById = NativeModules.NativeNetwork;
const user_id = 143697;
export default class Profile extends Component {
  // 构造函数
  constructor(props) {
    super(props);
    this.state = {
      //个人页面数据
      userData:'',
      //粉丝页面数据
      fansData:'',
      //关注页面数据
      FoucsData:'',
    };
    this.refreshFunction = this.refreshFunction.bind(this);
  }
//返回更新数据
refreshFunction(user_id){

  //个人页面数据
  getUserById.getUserById('143697')
  .then((data)=>{
    this.setState({userData:JSON.parse(data)})
  }).catch((err)=>{
    console.log("数据错误...." + err)
  })
  //粉丝页面数据
  getUserById.getFansList({'page':1,'user_id':143697,})
  .then((data)=>{
    //console.log('关注状态'  + JSON.parse(data))
    this.setState({fansData:JSON.parse(data)})
  }).catch((err)=>{
    console.log('数据错误......' + err)
  })
  //关注页面数据
  getUserById.getFolloweeList({'page':1,'user_id':143697})
  .then((data)=>{
    //console.log('data' + data);
    this.setState({FoucsData:JSON.parse(data)})
  }).catch((err)=>{
    console.log('数据错误..' + err)
  })
  
}
  // 加载完成
  componentDidMount(){
  this.refresh =   DeviceEventEmitter.addListener('refreshData',this.refreshFunction);

    this.refreshFunction();
  }
  componentWillMount(){

  }
  // view卸载
  componentWillUnmount(){
this.refresh && this.refresh.remove();

  }

  _goToPlayerView(){
    RnNativeModules.goToPlayerView('');
  }

_gotoFansView(user_id){

  RnNativeModules.hideTabBar('hide')
  this.props.navigator.push({
    component:MyFans,
    params:{
      user_id:user_id,
      fansData : this.state.fansData,
    }

  })
}
_gotoFoucesView(user_id){

  RnNativeModules.hideTabBar('hide')
  this.props.navigator.push({
    component:FoucsClass,
    params:{
      user_id:user_id,
      FoucsData:this.state.FoucsData,
    }
  })
}

_goToMyNoteList(_goToMyNoteList){
  RnNativeModules.hideTabBar('hide')
  this.props.navigator.push({
    component:MyNoteList,
    params:{
      user_id:user_id,

    }
  })
}

  // render
  render(){

      if (!this.state.userData) {
        return(<View></View>)
      }

      let user_id = this.state.userData.id;

        return(
          <View style={{flex:1,backgroundColor:'#ffffff'}}>
              <ScrollView >
                <View style={styles.renderForegroundView}>
                  <Image style={styles.bullyImage}/>

                  <TouchableOpacity style={styles.leftImage}>
                  <Image style={styles.leftImg} source= {require('../Course/images/play.png')} />
                  </TouchableOpacity>

                  <TouchableOpacity style={styles.rightImage} onPress={()=> this._goToPlayerView()}>
                  <Image style={styles.rightImg} source= {require('../Course/images/play.png')}/>

                  </TouchableOpacity>
                  <View style={styles.ForegroundView} >
                    <TouchableOpacity>
                    <Image style={styles.headerImage} source= {{uri:ImgUrl.baseImgUrl + 'user/' + this.state.userData.id +'/avatar'}} />
                      </TouchableOpacity>

                    <View style={styles.nameView}  >
                      <Text style={styles.nameText}>{this.state.userData.info.nickname}</Text>

                        <TouchableOpacity>
                      <Image  style={styles.editorImage}  source={require('../Course/images/g.png')}/>
                      </TouchableOpacity>
                    </View>

                    <View style = {styles.contentView} >
                      <Text style={styles.contentText}>{this.state.userData.info.intro   }</Text>
                    </View>
                            <View style={styles.buttomView} >
                                <TouchableOpacity onPress={()=>{this._gotoFansView(user_id)}}>
                              <View style={styles.FocusView}>
                                <Text style={styles.numberText}>{this.state.userData.stat.fans_count }</Text>
                                <Text style={styles.FocusText} >粉丝</Text>
                              </View>
                              </TouchableOpacity>

                              <TouchableOpacity onPress={()=>{this._gotoFoucesView(user_id)}} >
                              <View style={styles.FocusView}>
                                <Text style={styles.numberText}>{this.state.userData.stat.followee_count}</Text>
                                <Text style={styles.FocusText} >关注</Text>
                              </View>
                              </TouchableOpacity>

                              <TouchableOpacity onPress={() =>{this._goToMyNoteList(user_id)}} >
                              <View style={styles.FocusView}>
                                <Text style={styles.numberText}>{this.state.userData.stat.note_count}</Text>
                                <Text style={styles.FocusText} >心得</Text>
                              </View>
                              </TouchableOpacity>
                              </View>
                  </View>
                 </View>
                 <MyDownload />
                 <ProfileView  navigator = {this.props.navigator} user_id = {user_id}/>
              </ScrollView>
          </View>
        );

}
  // 自定义方法区域
  // your method

}

var styles = StyleSheet.create({
  renderBackground:{
    width:g_AppValue.screenWidth,
    height:292 *g_AppValue.precent,
    backgroundColor:'#ffffff',
  },
  renderForegroundView:{
    height:292  *g_AppValue.precent,
      backgroundColor:'#ffffff',

  },
  leftImage:{
    width:19  *g_AppValue.precent,
    height:19  *g_AppValue.precent,
  },
  leftImg:{
    position:'absolute',
    top:34  *g_AppValue.precent,
    left:13  *g_AppValue.precent,
    width:19  *g_AppValue.precent,
    height:19  *g_AppValue.precent,
  },
  rightImage:{
    position:'absolute',
    top:31  *g_AppValue.precent,
    right:14  *g_AppValue.precent,
    width:24  *g_AppValue.precent,
    height:24  *g_AppValue.precent,
  },
  rightImg:{
    width:24  *g_AppValue.precent,
    height:24  *g_AppValue.precent,
  },


  ForegroundView:{
    width:g_AppValue.screenWidth,
   height:212  *g_AppValue.precent,
  //  backgroundColor:'red',
    marginTop:60  *g_AppValue.precent,
    alignItems:'center',

  },
  headerImage:{
    width:77  *g_AppValue.precent,
    height:77  *g_AppValue.precent,
    borderRadius:38.5 *g_AppValue.precent,


  },
  nameView:{
    width:g_AppValue.screenWidth,
    height:16  *g_AppValue.precent,
    marginTop:8  *g_AppValue.precent,
    //backgroundColor:'#ffffff',
    justifyContent:'center',
    flexDirection:'row'
  },
  nameText:{
    fontSize:14  *g_AppValue.precent,
    color:'#5a5a5a',
    textAlign:'center',
     marginLeft:10  *g_AppValue.precent,
  },
  editorImage:{
    width:16  *g_AppValue.precent,
    height:16  *g_AppValue.precent,
     marginLeft:10,
  },
  contentView:{
    width:218  *g_AppValue.precent,
    height:26  *g_AppValue.precent,
  //  backgroundColor:'green',
    justifyContent:'center',
    alignItems:'center',
    marginTop:10  *g_AppValue.precent,
  },
  contentText:{
    fontSize:11  *g_AppValue.precent,
    color:'#9a9b9c',
    textAlign:'center',
  },
  buttomView:{
    width:g_AppValue.screenWidth,
    height:200,
   //backgroundColor:'yellow',
    marginTop:22  *g_AppValue.precent,
    flexDirection:'row',
    justifyContent:'space-around',
    marginBottom:20  *g_AppValue.precent,

  },
  FocusView:{
  //backgroundColor:'green',
  alignItems:'center',
},
numberText:{
  fontSize:16  *g_AppValue.precent,
  color:'#5a5a5a',

},
FocusText:{
  fontSize:11  *g_AppValue.precent,
  color:'#9a9b9c',
   marginTop:6  *g_AppValue.precent,
   marginBottom:2 *g_AppValue.precent,
},
bullyImage:{
  position:'absolute',
  width:57 *g_AppValue.precent,
  height:23 *g_AppValue.precent,
  top:105 *g_AppValue.precent,
  right:0 *g_AppValue.precent,
  backgroundColor:'red',
},

});
