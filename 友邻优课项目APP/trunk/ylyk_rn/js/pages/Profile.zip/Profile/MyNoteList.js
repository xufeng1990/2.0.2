//  MyNoteList
//  功能: TODO 该类的作用
//  Created by 刘云强 on  2016-10-20
//  Copyright © 2017年  琢磨科技.

'use strict';
import React, { Component,} from 'react';
import {
  Text,
  View,
  Image,
  TextInput,
  ScrollView,
  ListView,
  StyleSheet,
  TouchableOpacity,
  TouchableHighlight,
  TouchableWithoutFeedback,
  Alert,
  NativeModules
} from 'react-native';
import {
  SwRefreshScrollView,
  SwRefreshListView,
  RefreshStatus,
  LoadMoreStatus
} from 'react-native-swRefresh';
import g_AppValue from '../../configs/AppGlobal.js';
import *as ImgUrl from '../../configs/BaseImgUrl.js';
import Until from '../../common/util.js';
// 类
const getMyNoteList = NativeModules.NativeNetwork;
export default class MyNoteList extends Component {
  // 构造函数
  _page = 1;
  _dataSource = new ListView.DataSource({rowHasChanged:(row1,row2)=>row1 !== row2})
  _alldata =[];
  _followeeArr =[];
  constructor(props) {
    super(props);
    this.state = {
      dataSource:this._dataSource.cloneWithRows(this._alldata),
      isShowLoadMore:false,
    };
  }

  // 加载完成
  componentDidMount(){
       this._onListRefersh();
  }

  // view卸载
  componentWillUnmount(){
    //
  }
  _goBack(){
    this.props.navigator.pop();
  }

  _renderItem(item,i){
    return(
      <TouchableOpacity style = {styles.imageItem} onPress = {()=>{this._showModal()}}>
      <Image style={styles.imageItem} source= {{uri:item}}/>
    </TouchableOpacity>

    );
  }

  _rowRow(rowData,sectionID,rowID){
      console.log('rowData=====' + rowData.content)
   return(
     <View style={styles.cellView}>
       <View style={styles.cellContentView} >
          <Text style={styles.contentText} >{rowData.content}</Text>
            <View style = {styles.ImageView}>
             {rowData.images.map((item, i) => this._renderItem(item,i))}
            </View>
            <TouchableOpacity >
            <View style={styles.payView} >
              <Image style={styles.payImageOne} source={{uri:ImgUrl.baseImgUrl + 'course/' + rowData.course.id +'/cover'}} />
              <Image style={styles.payImageTwo} source= {require('../Course/images/Group.png')}/>
              <View style={styles.payRightView}>
                <Text style={styles.payRightTitleText}>{rowData.course.name}</Text>
                <Text style={styles.payRightNameText}>w;efm</Text>
              </View>
            </View>
          </TouchableOpacity>
          <View style={styles.ThumbView}>
            <TouchableOpacity >
            <Image style={styles.thumbImage} source={require('../../pages/Course/images/thumb.png')}/>
            </TouchableOpacity>
            <Text style={styles.thumbText} >{rowData.like_count}</Text>
            <TouchableOpacity style = {styles.deleteTextAction}>
            <Text style={styles.deleteText} >删除</Text>
              </TouchableOpacity>
          </View>

       </View>
       <View style={styles.timeView}>
         <Text style={{fontSize:18 * g_AppValue.precent,color:'#5a5a5a'}}>20</Text>
         <Text style={{fontSize:11 * g_AppValue.precent,color:'#9a9b9c',marginTop:7* g_AppValue.precent,}}> 3月</Text>
       </View>
     </View>
   );
  }

  // render
  render(){
    return (
      <View style={styles.container} >
        <View style={styles.headerView}>
          <View style={styles.headerContentView} >
            <TouchableOpacity style = {styles.backButtomA} onPress={()=>{this._goBack()}}>
          <Image style={styles.backButtom} source={require('../Course/images/back1.png')}/>
              </TouchableOpacity>
              <Text style={styles.headerTitle}>全部心得</Text>
          </View>
        </View>

        <SwRefreshListView
          ref = 'listView'
          style={styles.listView}
          enableEmptySections={true}
          dataSource={this.state.dataSource}
          renderRow={this._rowRow.bind(this)}
          onRefresh={this._onListRefersh.bind(this)}
          onLoadMore={this._onLoadMore.bind(this)}
          isShowLoadMore={this.state.isShowLoadMore}
          />

      </View>
    );
  }

  _onListRefersh(end){
    getMyNoteList.getNoteList({'page':this._page,'user_id':143697,'limit':'5'})
    .then((data) =>{

      var resultData = JSON.parse(data);
    let timer =  setTimeout(()=>{
      clearTimeout(timer)
      console.log("刷新成功 ")
        this._page ++
      for (let i = 0;i<resultData.length;i++){
        this._alldata.push(resultData[i]);

       }
      this.setState({
        dataSource : this._dataSource.cloneWithRows(this._alldata),
        isShowLoadMore:true,

      })

        //end()
      if (resultData.length < 5) {
        this.refs.listView.setNoMoreData();
      }else {
        this.refs.listView.resetStatus() //重置上拉加载的状态
      }
      //刷新成功后需要调用end结束刷新
      this.refs.listView.endRefresh() //建议使用end() 当然 这个可以在任何地方使用
    },1500)

  //end()
  }).catch((err)=> {
    console.warn('数据err', err);
  });
  }
  _onLoadMore(end){

    getMyNoteList.getNoteList({'page':this._page,'user_id':143697,'limit':'10'})
    .then((data) =>{
    //  console.log('data' + data)
      var resultData = JSON.parse(data);
      let timer =  setTimeout(()=>{
        clearTimeout(timer)
        this._page++
        for (let i = 0;i<resultData.length;i++){
          this._alldata.push(resultData[i]);

        }
        this.setState({
          dataSource:this._dataSource.cloneWithRows(this._alldata),
        //  is_followee:this._followeeArr,

        })
      //  let isNoMore = this._page > 2 //是否已无更多数据
     //结束
     //end(isNoMore)// 假设加载4页后


      if (resultData.length < 10) {
        this.refs.listView.setNoMoreData();
      }else {
        this.refs.listView.endLoadMore()
      }

          end()//加载成功后需要调用end结束刷新 假设加载4页后数据全部加载完毕
    //this.refs.listView.setNoMoreData();

      },2000)
  }).catch((err)=> {
    console.warn('数据err', err);
  });


  }
//
//
 }


var styles = StyleSheet.create({
  container:{
    flex:1,
    backgroundColor:'#f2f5f6'
  },
  headerView:{
    width:g_AppValue.screenWidth,
    height:64*g_AppValue.precent,
    backgroundColor:'#ffffff',
    marginBottom:10*g_AppValue.precent,

  },
  headerContentView:{
    width:g_AppValue.screenWidth,
    height:24*g_AppValue.precent,
  //  backgroundColor:'yellow',
    marginTop:31*g_AppValue.precent,
    justifyContent:'center',
    alignItems:'center',
  },
  headerTitle:{
    fontSize:18*g_AppValue.precent,
    color:'#5a5a5a',
  },
  backButtomA:{
    position:'absolute',
    width:10*g_AppValue.precent,
    height:18*g_AppValue.precent,
    left:12*g_AppValue.precent,
  },
  backButtom:{
    width:10*g_AppValue.precent,
    height:18*g_AppValue.precent,
  //  backgroundColor:'black',

  },
  cellView:{
    width:g_AppValue.screenWidth,
    backgroundColor:'#ffffff',
    marginBottom:10*g_AppValue.precent,
  },
  cellContentView:{
    width:284*g_AppValue.precent,
    //backgroundColor:'green',
    marginTop:20*g_AppValue.precent,
    marginLeft:79*g_AppValue.precent,
    marginRight:12*g_AppValue.precent,

  },
  contentText:{
    fontSize:14*g_AppValue.precent,
    color:'#5a5a5a',
    marginBottom:12*g_AppValue.precent,
  },
  ImageView:{
    width:304 * g_AppValue.precent,
    marginLeft:-20 * g_AppValue.precent,
    flexWrap:'wrap',
    flexDirection:'row',
    //backgroundColor:'red',
  },
    imageItem:{
      width:88* g_AppValue.precent,
      height:88 * g_AppValue.precent,
      marginBottom:10 * g_AppValue.precent,
      marginLeft:10 * g_AppValue.precent,
    },
    payView:{
      //marginTop:20 * g_AppValue.precent,
      width:284 * g_AppValue.precent,
      height:48 * g_AppValue.precent,
      flexDirection:'row',

    },
    payImageOne:{
      width:64 * g_AppValue.precent,
      height:48 * g_AppValue.precent,

    },
    payImageTwo:{
      position:'absolute',
      top:0 * g_AppValue.precent,
      width:64 * g_AppValue.precent,
      height:48 * g_AppValue.precent,
    },
    payRightView:{
      marginLeft:10 * g_AppValue.precent,
      width:210 * g_AppValue.precent,
      height:48 * g_AppValue.precent,
    },
    payRightTitleText:{
      marginTop:8 * g_AppValue.precent,
      fontSize:13 * g_AppValue.precent,
      color:'#5a5a5a',
      textAlign:'left',
    },
    payRightNameText:{
      marginTop:4 * g_AppValue.precent,
      fontSize:12 * g_AppValue.precent,
      color:'#5a5a5a',
      textAlign:'left',
    },
    ThumbView:{
      flex:1,
      height:16 * g_AppValue.precent,
      marginTop:15 * g_AppValue.precent,
      marginBottom:14 * g_AppValue.precent,
      marginRight:12* g_AppValue.precent,
      justifyContent:'flex-end',
      flexDirection:'row',
      //backgroundColor:'yellow',

    },
    thumbImage:{
      width:16 * g_AppValue.precent,
      height:16 * g_AppValue.precent,
      marginRight:6 * g_AppValue.precent,

    },
    thumbText:{
      fontSize:14 * g_AppValue.precent,
      color:'#9a9b9c',
      textAlign:'right',
    },
    deleteTextAction:{
      position:'absolute',
      top:5 * g_AppValue.precent,
      left:0 * g_AppValue.precent,
      marginBottom:14 * g_AppValue.precent,
    },
    deleteText:{
      fontSize:11 * g_AppValue.precent,
      color:'#9a9b9c',
    },
    timeView:{
      width:50* g_AppValue.precent,
      position:'absolute',
      top:19 * g_AppValue.precent,
      left:12* g_AppValue.precent,
      //backgroundColor:'yellow',
      flexDirection:'row',
    }

})
